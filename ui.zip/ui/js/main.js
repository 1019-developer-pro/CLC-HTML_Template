// Bootstrap 5 makes the mobile toggle native, so we don't need the old toggle function.
// This script now solely handles adding the 'active' class to the current nav link.

document.addEventListener('DOMContentLoaded', () => {
    const currentLocation = location.href;
    const menuItems = document.querySelectorAll('.nav-link');

    // Remove active class from all first (to avoid duplicates if hardcoded)
    menuItems.forEach(item => {
        if (item.href === currentLocation) {
            // Remove 'active' from others if needed, or just ensure this one has it.
            // Bootstrap uses 'active' class on the .nav-link
            item.classList.add('active');
        }
        // Optional: Remove active from others if you want strictly one active link
        // else item.classList.remove('active');
    });
});
